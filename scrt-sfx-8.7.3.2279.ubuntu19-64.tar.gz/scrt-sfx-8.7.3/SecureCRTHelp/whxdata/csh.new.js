(function() {



  


var mapData = []
window.rh.model.publish("temp.data", mapData, { sync:true });
})();
