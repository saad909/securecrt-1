(function() {
var glossary =  {"type":"glossary","chunkinfos":[{"type":"chunkinfo","first":"alphanumeric","last":"Zmodem","num":"35","node":"gdata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), glossary, { sync:true });
})();
