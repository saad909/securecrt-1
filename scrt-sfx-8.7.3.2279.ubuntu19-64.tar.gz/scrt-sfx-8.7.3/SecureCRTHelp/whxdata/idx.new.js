(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"256-color extensions","last":"zoom","num":"725","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
