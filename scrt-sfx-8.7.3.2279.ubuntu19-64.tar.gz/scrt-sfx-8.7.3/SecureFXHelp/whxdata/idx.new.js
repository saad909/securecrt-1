(function() {
var index =  {"type":"index","chunkinfos":[{"type":"chunkinfo","first":"About SecureFX","last":"Zmodem","num":"605","node":"idata1"}]};
window.rh.model.publish(rh.consts('KEY_TEMP_DATA'), index, { sync:true });
})();
